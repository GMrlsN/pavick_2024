import {HomeTemplate } from "../index";
export function PageBase(){
    return (<HomeTemplate/>);
}

import { LoginTemplate} from "../index";
export function Login(){
    return (<LoginTemplate/>);
}
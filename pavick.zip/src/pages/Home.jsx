import {HomeTemplate } from "../index";
export function Home(){
    return (<HomeTemplate/>);
}

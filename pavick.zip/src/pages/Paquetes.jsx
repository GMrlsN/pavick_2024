import { useQuery } from "@tanstack/react-query";
import { PaqueteTemplate, usePaqueteStore, SpinnerLoader } from "../index";

export function Paquetes() {
  const { mostrarPaquete, datapaquete, buscarPaquete, buscador } = usePaqueteStore();

  // Verifica si datapaquete no es null o undefined antes de acceder a sus propiedades
  const idPaquete = datapaquete ? datapaquete.id_paquete : null;

  // Consulta para mostrar el paquete
  const { isLoading: isLoadingMostrar, error: errorMostrar, data: dataMostrar } = useQuery({
    queryKey: ["mostrar paquete", { id_paquete: idPaquete }],
    queryFn: () => mostrarPaquete({ id_paquete: idPaquete }),
    enabled: idPaquete !== null, // Consulta habilitada solo si idPaquete no es null
  });

  // Consulta para buscar el paquete
  const { isLoading: isLoadingBuscar, error: errorBuscar, data: buscarData } = useQuery({
    queryKey: ["buscar paquete", { id_paquete: idPaquete, nombre: buscador }],
    queryFn: () => buscarPaquete({ id_paquete: idPaquete, nombre: buscador }),
    enabled: idPaquete !== null && buscador !== null, // Consulta habilitada solo si idPaquete y buscador no son null
  });

  if (isLoadingMostrar || isLoadingBuscar) {
    return <SpinnerLoader />;
  }

  if (errorMostrar || errorBuscar) {
    console.log("error", errorMostrar || errorBuscar);
    return <span>Error</span>;
  }

  // Usar los datos obtenidos de las consultas
  const paqueteData = buscarData || dataMostrar;

  return <PaqueteTemplate data={paqueteData} />;
}

import {ConfiguracionTemplate } from "../index";
export function Configuracion(){
    return (<ConfiguracionTemplate/>);
}
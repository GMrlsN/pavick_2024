import styled from "styled-components";
export const Title = styled.span`
    font-weight:700;
  font-size:30px;
`
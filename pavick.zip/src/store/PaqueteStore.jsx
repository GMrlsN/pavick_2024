import { create } from "zustand";
import { BuscarPaquete, 
    MostrarPaquete, 
    EliminarPaquete, 
    InsertarPaquete, 
} from "../index";

export const usePaqueteStore = create((set, get) => ({
    buscador:"",
    setBuscador:(p)=>{
        set({buscador:p});
    },
    datapaquete: [],
    paqueteItemSelect:[],
    parametros:{},
    mostrarPaquete: async (p) => {
        const response = await MostrarPaquete(p);
        set({parametro:p});
        set({datapaquete:response});
        set({paqueteItemSelect:response[0]});
        return response;
    },
    selectPaquete:(p)=>{
        set({paqueteItemSelect:p});
    },
    insertarPaquete: async (p) => {
        await InsertarPaquete(p);
        const {mostrarPaquete}=get();
        const{parametros}=get();
        set(mostrarPaquete(parametros));
    },
    eliminarPaquete: async (p) => {
        await EliminarPaquete(p);
        const {mostrarPaquete}=get();
        const{parametros}=get();
        set(mostrarPaquete(parametros));
    },
    editarPaquete: async (p) => {
        await EditarPaquete(p)
        const {mostrarPaquete}=get();
        const{parametros}=get();
        set(mostrarPaquete(parametros));
    },
    buscarPaquete: async (p) => {
        const response = await BuscarPaquete(p);
        set({datapaquete:response});
    }
}));